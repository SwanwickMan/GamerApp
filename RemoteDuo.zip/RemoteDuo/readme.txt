LelouchAWhoosh sends commands 
Xbox Remote recieves and executes commands

If an invalid IP is inputted LelouchAWhoosh will crash
Place a file called file.gamerIP in the same directory as LelouchAWhoosh.exe to automatically read the files contents as an IP when no IP is given on run

Xbox Remote should be placed in the windows start-up folder
This can be accessed by running shell:startup via the window button
Give Xbox Remote admin via Properties > Compatibility > Change Settings for all users > Run this program as administrator 